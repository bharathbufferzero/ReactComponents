import _ from 'lodash'
export function Paginate(items,PageNumber,pageSize){
    console.log(items)
const startIndex = (PageNumber-1)*pageSize;
console.log(_(items).slice(startIndex).take(pageSize).value())
return _(items).slice(startIndex).take(pageSize).value()
}