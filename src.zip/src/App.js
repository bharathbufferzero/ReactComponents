import logo from './logo.svg';
import './App.css';
import 'font-awesome/css/font-awesome.css'
import Hello from './components/hello';
import Example from './components/example'
import Table from './components/Table'
import Parent from './components1/parent'
import Movies from './components1/movies'
import Movies1 from './components1/movies'
import ParentCounter from './Assignment/ParentCounter';
import Numberword from './components/numberWord'
function App() {
  return (
    <div className="App">
      {/* <Hello/>
      <Example/>  */}
       
          {/* <Table/> */}
          <Movies/>

          
      {/* <Parent/> */}
      {/* <ParentCounter/> */}
      {/* <Numberword/> */}
      
    </div>
  );
}

export default App;


