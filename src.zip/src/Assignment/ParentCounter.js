import React, { Component } from "react";
import ChildCounter from "./ChildCounter";
class ParentCounter extends Component {
  state = {
    counters: [
      { id: 1, count: 0, hidebutton: true },
      { id: 2, count: 0, hidebutton: true },
      { id: 3, count: 0, hidebutton: true },
      { id: 4, count: 0, hidebutton: true },
    ],
    deleteCounter: 0,
  };
  incrementHandler = (counter) => {
    const counters = [...this.state.counters];
    const index = counters.indexOf(counter);
    counters[index] = { ...counter };
    counters[index].count++;
    counters[index].hidebutton = false;
    this.setState({
      counters,
    });
    console.log(counters[index]);
  };

  decrementHandler = (counter) => {
    if (counter.count > 0) {
      const counters = [...this.state.counters];
      const index = counters.indexOf(counter);
      counters[index] = { ...counter };
      counters[index].count--;
      if (counters[index].count === 0) {
        counters[index].hidebutton = true;
      }
      this.setState({
        counters,
      });
    }
    const counters = [...this.state.counters];
    if (counters.indexOf(counter).count === 0) {
      const index = counters.indexOf(counter);
      counters[index] = { ...counter };
      counters[index].hidebutton = !this.state.counters[index].hidebutton;
      console.log(counters[index]);
      this.setState(counters);
    }
    console.log(this.state.counters);
  };

  deleteHandler = (counter) => {
    const counters = this.state.counters.filter((c) => c.id !== counter.id);
    this.setState({
      counters,
    });
    this.deleteCountHandler();
  };
  deleteCountHandler = () => {
    this.setState({ deleteCounter: this.state.deleteCounter + 1 });
    console.log(this.state.deleteCounter);
  };
  countFormatHandler = (countValue) => {
    return countValue === 0 ? "zero" : countValue;
  };
  btnStyleHandler = (countValue) => {
    let classes = "btn btn-";
    classes += countValue === 0 ? "primary" : "warning";
    return classes;
  };
  resetHandler = () => {
    const counters = [...this.state.counters];
    counters.map((counter) => [
      (counter.count = 0),
      (counter.hidebutton = true),
    ]);
    this.setState({ counters });
  };

  render() {
    return (
      <div>
        <navbar
          className="navbar navbar-expand-lg navbar-light bg-light p-3 "
          style={{ color: "grey", textAlign: "left" }}
        >
          <h1 className="ms-5 p-2">
            No of items Deleted : {"  "}
            <button className="btn btn-dark ">{this.state.deleteCounter}</button>
          </h1>
        </navbar>
        <div className="row">
          <div className="col-md-2">
            <button
              className="btn btn-primary resetBtn"
              onClick={this.resetHandler}
            >
              Reset
            </button>
          </div>

          <div className="col-md-8 mt-5">
            {this.state.counters.map((counter) => {
              return (
                <ChildCounter
                  count={counter.count}
                  key={counter.id}
                  hidebutton={counter.hidebutton}
                  incrementclick={this.incrementHandler}
                  decrementclick={this.decrementHandler}
                  deleteclick={this.deleteHandler}
                  countFormat={this.countFormatHandler}
                  counter={counter}
                  btnStyle={this.btnStyleHandler}
                  deleteCount={this.state.deleteCounter}
                />
              );
            })}
          </div>
          <div className="col-md-2"> </div>
        </div>
      </div>
    );
  }
}

export default ParentCounter;
