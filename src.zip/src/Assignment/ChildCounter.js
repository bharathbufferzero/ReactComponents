import React from "react";
const childCounter = (props) => {
  return (
    <>
      <ul className="list-group list-group-horizontal">
        <li className="list-group-item  mb-4">
          <button className={props.btnStyle(props.count)}>
            {props.countFormat(props.count)}
          </button>
        </li>
        <li
          className="list-group-item mb-4 "
          onClick={() => props.incrementclick(props.counter)}
        >
          <button className="btn btn-success">
            <i className="fa fa-plus"></i>
          </button>
        </li>
        <li
          className="list-group-item mb-4 "
          onClick={() => props.decrementclick(props.counter)}
        >
          <button className="btn btn-dark" disabled={props.hidebutton}>
            <li className="fa fa-minus"></li>
          </button>
        </li>
        <li
          className="list-group-item mb-4 "
          onClick={() => props.deleteclick(props.counter)}
        >
          <button className="btn btn-danger">
            <i className="fa fa-trash"></i>
          </button>
        </li>
      </ul>
    </>
  );
};

export default childCounter;
