import React, { Component } from 'react';
class Child extends Component {
    state = {
        counter:this.props.counter
        
      }
      submitHandler=()=>{
          this.setState({
              value:this.state.value +1
          })
      }
    render() { 
        return ( <div>
            <button class="btn btn-danger" onClick={this.submitHandler}>{this.state.value} , {this.state.age}</button>
        </div> );
    }
}
 
export default Child;



