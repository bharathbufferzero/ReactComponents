import React from 'react';
import _ from 'lodash'


const Pagination =(props)=>{
  const{itemCount,pageSize,currentPage,onpageChange}=props;
  const pagesCount=Math.ceil(itemCount/pageSize);
  console.log(pagesCount)
 const pages= _.range(1,pagesCount+1)
console.log(pages)

  return(
    <nav aria-label="Page navigation example ">
      <ul className="pagination">
        {pages.map((page)=>{
          return(       
             <li key={page} className={currentPage===page ?"page-item active active2  ":"page-item "}  >
               <a className="page-link" onClick={()=>onpageChange(page) }> {page}</a></li>
          )
        })}
      </ul>

    </nav>
  )
}
export default Pagination