import React from 'react';

const ListGroup = (props) => {
    var { items, textProperty, valueProperty, onItemSelected, selectedIteam } = props;
   
    return (
        <ul className="list-group tableAlter">
        {/* <li className="list-group-item " onClick={<AllMovies allMovies={props.allMoviesHandler}/>} > All Movies</li> */}
        <li className="list-group-item " onClick={props.allMovies}> All Movies</li>
        
            {items.map((item) => {
                return <li key={item[valueProperty]} className={item === selectedIteam ? "list-group-item active active2" : "list-group-item"} onClick={() => onItemSelected(item)} >{item[textProperty]}</li>
            })}
        </ul>);
}

ListGroup.defaultProps = {
    textProperty: "name",
    valueProperty: "_id"
}

export default ListGroup;