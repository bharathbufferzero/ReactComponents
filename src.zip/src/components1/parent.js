import React, { Component } from 'react';
import Child from './child';
class Parent extends Component {
    state = { 
        counter:[
            {value:1 , age:20},
            {value:2 , age:20},
            {value:3 , age:20},
            {value:4 , age:20},
            {value:5  , age:20}
        ]
     }

    
    // handleIncrement=(counter)=>{
    //     const counters=[...this.state.counters]
    //     const index=counters.indexOf(counter)
    //     counters[index]={...counter}
    //     counters[index].value++;
    //     this.setState({
    //         counters
    //     })
    // }
     
    render() { 
        return ( <div>
            {this.state.counter.map((count,index) =>{
                return(<div ><Child 
                    value={count.value} age={count.age}
                   counter={count}
                    
                />
            </div>)
            })}
            
        </div> );
    }
    
}

export default Parent;