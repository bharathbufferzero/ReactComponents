import React from 'react';
const AllMovies = (props) =>
 {
    return(<div>
       <li className="list-group-item " onClick={props.allMovies} > All Movies</li>
    </div>)
 }
 
export default AllMovies;