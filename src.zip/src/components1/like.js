import React, { Component } from 'react';
class Like extends Component {
    
    render() { 
        let classes="fa fa-heart"
        if(!this.props.liked) classes+="-o"
        console.log(this.props.liked)
        return ( 
            <li className={classes} onClick={this.props.onClick}></li>
         );
    }
}
 
export default Like ;