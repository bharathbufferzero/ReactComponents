import React, { Component } from "react";
import { getMovies } from "../data/moviesdatra";
import { getGenres} from '../data/genresData'
import Pagination from './pagination'
import {Paginate} from '../utils/paginate'
import ListGroup from './listgroup'
import AllMovies from './allMovies'
class Movies extends Component {
  state = {
    movies: getMovies(),
    pageSize:4,
    currentPage:1,
    genres:getGenres(),
    allMovies:false,
    
  };

  deleteItem = (movie) => {
    const movies = this.state.movies.filter((m) => m._id !== movie._id);
    console.log(movies)
    this.setState({
      movies,
    });
    console.log(this.state.movies);
  };

  handleLike = (movie) => {
    const movies = [...this.state.movies];
    console.log(movies);
    const index = movies.indexOf(movie);
    // movies[index]={...movies[index]}

    movies[index].liked = !movies[index].liked;

    this.setState({ movies });
  };


  handlepageChange=(page)=>{

    this.handle1()
    this.setState({currentPage:page,allMovies:false})
    console.log(page)
    
  }
  handleGenerSelect = (genre) => {
    
    this.setState({
      selectedGener: genre,
      allMovies:false,
      currentPage:1,
      
    })
    
    console.log(this.state.selectedGener)
  }
  handle1=()=>{
    this.setState({
      selectedGener:false,
      
    })
    console.log(this.state.selectedGener)
  }
  allmoviesHandler=()=>{
   
    this.setState({selectedGener:false,currentPage:1})
  }
  render() {
    
    if (this.state.movies.length === 0) {
      return <h1>"No Movies to show"</h1>;
    }
    let filtered=[]
    let movies=""
    if(this.state.selectedGener){
      filtered =  this.state.movies.filter(m => m.genre._id === this.state.selectedGener._id) 
       movies=Paginate(filtered,this.state.currentPage,this.state.pageSize)
    }
    // else if(this.state.allMovies ){
      
    //     movies=[...this.state.movies]
        
    //     // movies=Paginate(this.state.movies,this.state.currentPage,this.state.pageSize)
      
    // }
    // else{
    //   filtered=[...this.state.movies]
    //    movies=Paginate(filtered,this.state.currentPage,this.state.pageSize)
    // }
    
    else{
         filtered=[...this.state.movies]
          movies=Paginate(filtered,this.state.currentPage,this.state.pageSize)
      }
   
    
    return (
      <div>
        <div className="row">
       <div className ="col-md-2">
       <ListGroup
            items={this.state.genres}
            selectedIteam={this.state.selectedGener}
            onItemSelected={this.handleGenerSelect} 
            movies={this.state.movies}
            allMovies={this.allmoviesHandler}
            item11="All Movies" />
        </div>
         
        <div className ="col-md-8">
          <div className="tableAlter" id="table1">
          <h1>No of Movies showing : <button className="btn btn-dark"> {this.state.movies.length}</button></h1>
        <table className="table rounded">
          <thead className="thead bg-light">
            <tr className="text-secondary ">
              <th style={{ width: "200px ", height: "60px" }}>Title</th>
              <th style={{ width: "200px ", height: "60px" }}>Genre</th>
              <th style={{ width: "200px ", height: "60px" }}>numberInStock</th>
              {/* <th scope="col">PublishDate</th> */}
              <th style={{ width: "200px ", height: "60px" }}>
                dailyRentalRate
              </th>
              <th style={{ width: "200px ", height: "60px" }}></th>
              <th style={{ width: "200px ", height: "60px" }}>DeleteItem</th>
            </tr>
          </thead>
          <tbody>
            {movies.map((movie) => {
              return (
                <tr className="rowpop" key={movie._id}>
                  <td>{movie.title}</td>
                  <td>{movie.genre.name}</td>

                  <td>{movie.numberInStock}</td>
                  {/* <td>{movie.publishDate}</td> */}
                  <td>{movie.dailyRentalRate}</td>
                  <td>
                    <li
                      className={!movie.liked ? "fa fa-heart-o" : "fa fa-heart red-color"}
                      onClick={() => this.handleLike(movie)}   
                    ></li>
                  </td>
                  <td>
                    <button
                      onClick={() => this.deleteItem(movie)}
                      className="btn btn-danger"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
       <Pagination  currentPage ={this.state.currentPage} itemCount={this.state.movies.length} pageSize={this.state.pageSize} onpageChange={this.handlepageChange}/>

          </div>
        
        </div>
        </div>
        
        
      </div>
    );
  }
}
console.log(getMovies);

export default Movies;
