import React, { Component } from 'react';
class Hello extends Component {
    state = {  }
    render() { 
        return ( <div>
            <h1>Heloo EveryOne</h1>
        </div> );
    }
}
 
export default Hello;