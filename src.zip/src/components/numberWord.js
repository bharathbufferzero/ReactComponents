import React, { Component } from 'react';
class Numberword extends Component {
    state = { number:123,
    hundred:"hundred" ,numb:{1:"one",2:"two",3:"three",4:"four",5:"five",6:"six",7:"seven", 8:"eight",9:"nine",0:"zero"} }
        

    numberChange=(number)=>{
        var i=1;
        while(number>9){
           let numb=Math.floor(number/10);
           console.log(numb)
           i++
           
           number=numb
           console.log(i)

        }
        console.log(i)
        if(i==1){
            
            for(var n in this.state.numb){
                if(this.state.number==n){
                    const num=this.state.numb[n]
                    console.log(num)
                    this.setState({number:num})
                
                }
                

            }
        }

       


    }
    render() { 
        return ( <div>
            <button onClick={()=>this.numberChange(this.state.number)}>{this.state.number}</button>
        </div> );
    }
}
 
export default Numberword;