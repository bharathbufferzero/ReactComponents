import React, { Component } from 'react';
class Table extends Component {
    state = { 
        persons:[
            {firstname:"Bharath",lastName:"Gowda" ,email:25},
            {firstname:"Abhishek",lastName:"kumar" ,email:25},
            {firstname:"Rashmi",lastName:"Ranjan" ,email:25},
            {firstname:"subhendu",lastName:"Gowda" ,email:25},
            {firstname:"shalini",lastName:"shetty" ,email:25},
            {firstname:"sushanth",lastName:"Maharana" ,email:25}
        ]
     }
    
   
    deleteItem=(item)=>{
      console.log(this.state.persons[item])
      //delete this.state.persons[item]
      this.state.persons.splice(item,1)
      console.log(this.state.persons[item])
      console.log(this.state.persons)
      this.setState({
        persons:[...this.state.persons]
      })
  }
    addItem=(index)=>{
      console.log(index)
      
      this.state.persons.splice(index,0,{firstname:"Rahul",lastName:"Gandhi",email:30})
      this.setState({
        persons:[...this.state.persons]
        
      })
      console.log(this.state.persons)

    }
   

    render() { 
        return ( <div>
          
            <table className="table">
  <thead>
    <tr>
      <th scope="col">FirstName</th>
      <th scope="col">LastName</th>
      <th scope="col">Email</th>
      <th scope="col">Delete</th>
    </tr>
  </thead>
  <tbody >
    {this.state.persons.map((person,index)=>{
       return( <tr key="{index}">
        <td>{person.firstname}</td>
        <td>{person.lastName}</td>
        <td>{person.email}</td>
        <td><button onClick={()=>this.deleteItem(index)} class="btn btn-danger">Delete</button></td>
        
      </tr>
    );})}
    
   

   
  </tbody>
</table>

     
<button class="btn btn-success" onClick={()=>this.addItem(this.state.persons.length)} >Add Items</button>

        </div>
        );
}

// deleteItem=(item)=>{
//     console.log(this.state.persons[item])
//     delete this.state.persons[item]
//     console.log(this.state.persons[item])
//     console.log(this.state.persons)
// }
}
export default Table;

