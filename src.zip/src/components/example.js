import React, { Component } from 'react';

class Example extends Component {
    state ={
        count:0,
        imgUrl:"https://picsum.photos/200"
    }
    submit=()=>{
        this.setState({
            count:this.state.count + 1
        })
    }
    style={
        fontSize:45,
        color:"red",

    }

    render() { 
        return ( 
            <div>
                <button onClick={this.submit}>Increment</button>
                <h1> Counter={this.formatcount()}</h1>
                <button class="btn btn-primary">ABSHDHDH</button>
                <img src ={this.state.imgUrl} />
                <span style={{fontSize:50},{color:"blue"}}> ABCHHHDSU</span>
                <h1 style={this.style}>Basavaaaaraju</h1>
            </div>
         );
    }
     formatcount =()=>{
        return this.state.count===0?"Zero":this.state.count
    }
    

}
 
export default Example;